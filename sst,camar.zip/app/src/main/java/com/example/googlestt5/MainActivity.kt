package com.example.googlestt5

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech




class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {



   }