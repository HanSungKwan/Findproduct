package com.app_software.camera_gpt

import android.Manifest.permission.CAMERA
import android.Manifest.permission.WRITE_EXTERNAL_STORAGE
import android.Manifest
import android.content.pm.PackageManager
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.app_software.camera_gpt.ImageUploader.Companion.uploadImage
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.*
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import java.io.ByteArrayOutputStream

// YourService 인터페이스와 YourResponse 데이터 클래스를 MainActivity 클래스 외부에 위치시킵니다.
interface YourService {
    @Multipart
    @POST("/tFile/")
    fun uploadImage(@Part image: MultipartBody.Part): Call<YourResponse>
}

data class YourResponse(val success: Boolean, val message: String)

class ImageUploader {
    companion object {
        fun uploadImage(bitmap: Bitmap) {
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream)
            val imageBytes = stream.toByteArray()
            val requestBody = imageBytes.toRequestBody("image/jpeg".toMediaTypeOrNull())
            val multipartBody = MultipartBody.Part.createFormData("inFile", null, requestBody)

            val retrofit = Retrofit.Builder()
                .baseUrl("http://114.70.92.44:11000/tFile/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()
            val service = retrofit.create(YourService::class.java)
            val call = service.uploadImage(multipartBody)
            call.enqueue(object : Callback<YourResponse> {
                override fun onResponse(call: Call<YourResponse>, response: Response<YourResponse>) {
                    val yourResponse = response.body()
                    if (yourResponse != null && yourResponse.success) {
                        // TODO: 이미지 전송이 성공적으로 끝났을 때 처리할 코드 작성
                        Log.d("고", "1")
                    } else {
                        // TODO: 이미지 전송이 실패했을 때 처리할 코드 작성
                        Log.d("고은", "2")
                    }
                }

                override fun onFailure(call: Call<YourResponse>, t: Throwable) {
                    // TODO: 이미지 전송이 실패했을 때 처리할 코드 작성
                    Log.d("고은성", "3")
                }
            })
        }
    }
}

class MainActivity : AppCompatActivity() {
    //private val REQUEST_IMAGE_CAPTURE = 1

    // registerForActivityResult 사용하여 takePicture 선언
    private val takePicture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data: Intent? = result.data
            val imageBitmap = data?.extras?.get("data") as Bitmap
            uploadImage(imageBitmap)
        }
    }

    private val PERMISSION_CODE = 200

    private var isPermissionGranted = false

    private fun dispatchTakePictureIntent() {
        // 권한 확인 후 카메라 앱 실행
        if (isPermissionGranted) {
            Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
                takePictureIntent.resolveActivity(packageManager)?.also {
                    // startActivityForResult 대신 takePicture.launch()를 호출
                    takePicture.launch(takePictureIntent)
                    Log.d("고은성ㅇ", "4")
                }
            }
        } else {
            // 권한 요청
            val permission = arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            ActivityCompat.requestPermissions(this, permission, PERMISSION_CODE)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
                && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                // 권한이 허용되면 isPermissionGranted를 true로 설정하고 카메라 앱 실행
                isPermissionGranted = true
                dispatchTakePictureIntent()

            } else {
                // 권한이 거부되면 앱 종료
                finish()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // onCreate에서 권한 확인
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            // 권한이 허용되면 isPermissionGranted를 true로 설정
            isPermissionGranted = true
        } else {
            val permission = arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            ActivityCompat.requestPermissions(this, permission, PERMISSION_CODE)
        }

        // 권한이 허용되어 있으면 카메라 앱 실행
        if (isPermissionGranted) {
            dispatchTakePictureIntent()
        }
    }
}

//    private fun uploadImage(bitmap: Bitmap) {
//        val stream = ByteArrayOutputStream()
//        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream)
//        val imageBytes = stream.toByteArray()
//        val requestBody = imageBytes.toRequestBody("image/jpeg".toMediaTypeOrNull())
//        val multipartBody = MultipartBody.Part.createFormData("inFile", null, requestBody)
//
//        val retrofit = Retrofit.Builder()
//            .baseUrl("http://114.70.92.44:11000/tFile/")
//            .addConverterFactory(GsonConverterFactory.create())
//            .build()
//        val service = retrofit.create(YourService::class.java)
//        val call = service.uploadImage(multipartBody)
//        call.enqueue(object : Callback<YourResponse> {
//            override fun onResponse(call: Call<YourResponse>, response: Response<YourResponse>) {
//                // TODO: Handle the response here
//            }
//
//            override fun onFailure(call: Call<YourResponse>, t: Throwable) {
//                // TODO: Handle the failure here
//            }
//        })
//    }
//
//
//interface YourService {
//    @Multipart
//    @POST("/tFile/") // 서버의 엔드포인트 URL 입력
//    fun uploadImage(@Part image: MultipartBody.Part): Call<YourResponse>
//}
//
//data class YourResponse(val success: Boolean, val message: String)